[x] 1. Install the required packages
[x] 2. Restart the workflow to see if the project is working
[x] 3. Migrate Supabase to Neon Postgres
  [x] Note: Supabase has no database tables - only used for video proxy edge function. Firebase is the primary backend. No migration needed.
[x] 4. Verify the project is working using the feedback tool
[x] 5. Inform user the import is completed and they can start building, mark the import as completed using the complete_project_import tool
